
@extends('layouts/layout')

@section('title', 'Show Details')

@section('main')
<h2>{{$task->title}}</h2>
<p>{{$task->description}}</p>
<p>{{$task->created_at}}</p>
<p> La date de création de la tâche est le : {{ \Carbon\Carbon::parse($task->created_at)->Format('d F Y')}}</p>
<a href="{{$task->id}}/delete"><input type='button' value='Delete the task'></a>

@endsection

