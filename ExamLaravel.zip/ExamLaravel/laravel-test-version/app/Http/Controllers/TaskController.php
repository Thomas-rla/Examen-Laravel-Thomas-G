<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function index()
    {
        return view('index', [
            'tasks' => \App\Models\Task::all(),
        ]);
    }

    public function show($task_id)
     {  
     $task=\App\Models\Task::find($task_id);

        return view('show', [
            'task' => $task,
        ]);
    }

    public function delete($task_id)
     {  
        $task=\App\Models\Task::find($task_id);
        $task->delete();
        return view('task-delete', [
            'id' => $task_id
        ]);
    }
}
