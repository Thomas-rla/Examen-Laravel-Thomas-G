


<?php $__env->startSection('title', 'Show Details'); ?>

<?php $__env->startSection('main'); ?>
<h2><?php echo e($task->title); ?></h2>
<p><?php echo e($task->description); ?></p>
<p><?php echo e($task->created_at); ?></p>
<p> La date de création de la tâche est le : <?php echo e(\Carbon\Carbon::parse($task->created_at)->Format('d F Y')); ?></p>
<a href="<?php echo e($task->id); ?>/delete"><input type='button' value='Delete the task'></a>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\thoma\ExamLaravel\laravel-test-version\resources\views/show.blade.php ENDPATH**/ ?>